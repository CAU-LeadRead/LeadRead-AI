import mysql_reviews
import pymysql
from sklearn.decomposition import TruncatedSVD
from scipy.sparse.linalg import svds
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
import sys
import warnings
import argparse
import json


def get_perfume_data():
    cursor = mysql_reviews.get_cursor()

    reviews_dict = mysql_reviews.get_reviews(cursor)

    user_perfume_data = pd.DataFrame(reviews_dict)

    user_perfume_data["title"] = (
        user_perfume_data["en_name"] + "/" + user_perfume_data["brand"]
    )

    user_perfume_data["rating"] = user_perfume_data["stars"].apply(pd.to_numeric)
    user_perfume_data["userId"] = user_perfume_data["UserNick"]
    nich = user_perfume_data[["userId", "title", "category"]]

    user_perfume_data.drop(
        [
            "id",
            "kr_brand",
            "kr_name",
            "longevity",
            "mood",
            "comment",
            "FragranceBrand",
            "brand",
            "en_name",
            "stars",
            "UserNick",
            "category",
        ],
        axis=1,
        inplace=True,
    )
    return user_perfume_data, nich


def get_corr():
    user_perfume_data, nich = get_perfume_data()
    user_perfume_rating = user_perfume_data.pivot_table(
        "rating", index="userId", columns="title"
    ).fillna(0)
    perfume_user_rating = user_perfume_rating.T
    SVD = TruncatedSVD(n_components=12)
    matrix = SVD.fit_transform(perfume_user_rating)
    corr = np.corrcoef(matrix)
    perfume_title = user_perfume_rating.columns
    return corr, perfume_title


def get_similar(perfume_name):
    user_perfume_data, nich = get_perfume_data()
    nich = nich.loc[nich["category"].isin([1])]["title"].values
    corr, perfume_title = get_corr()
    perfume_title_list = list(perfume_title)
    corr_index = perfume_title_list.index(perfume_name)
    result = list(perfume_title[(corr[corr_index] >= 0.9)])
    for r in result:
        if r not in nich:
            result.remove(r)
    return result


def main():
    name = sys.argv[1]
    brand = sys.argv[2]
    perfume_name = name + "/" + brand
    similars = get_similar(perfume_name)
    result = []
    for sim in similars:
        result.append({"brand": sim.split("/")[0], "name": sim.split("/")[1]})
    result = json.dumps({"detected": result})
    print(result)


print(get_similar("rose 31/le labo"))
